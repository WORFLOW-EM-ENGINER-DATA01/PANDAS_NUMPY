import numpy as np 

DIM = 5
MAX_NUM = 50

dataset = np.random.randint(1, MAX_NUM, size=(DIM, DIM) )

print(dataset)

# 1. Générez une liste des multiples de 11 inférieurs à MAX_NUM
y = [ x * 11 for x in range(MAX_NUM//11 + 1)]

# print( np.isin(dataset, y) )
# sur les lignes
mask = np.any( np.isin(dataset, y), axis=1)
print(mask)

# 2. En utilisant np.isin(dataset, multiple11 ) trouvez tous les nombres multiples de 11 dans le dataset. Donnez le nombre de chaque multiple présent 
# Dans ce tableau

# print( dataset[ np.isin(dataset, y) ])

m = np.unique(dataset[ np.isin(dataset, y) ] )

u, count = np.unique( dataset[ np.isin(dataset, y) ], return_counts=True)

print( dict( zip(u, count)) )

# print(dataset)

# 3. Supprimez maintenant toutes les lignes du tableau ayant au moins un 0

# En utilisant le mask

# Négation sur les bits
mask = ~ mask
# sur chaque ligne on applique le mask
print(dataset[mask, :])


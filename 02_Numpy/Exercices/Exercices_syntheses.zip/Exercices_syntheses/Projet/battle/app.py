import Game as g



game = g.Game('cards.txt')

game.run()

print(game.turns)
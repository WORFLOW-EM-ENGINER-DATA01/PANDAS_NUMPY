
import numpy as np 

a = np.array([
    [13, 22, 28, 66, 40],
    [16, 59, 37, 33, 28],
    [34, 98, 54, 48, 96],
    [13, 84, 93, 79, 76],
    [63, 50, 12, 69, 12]
])


posMinLine = []

for i, line in enumerate(a):
    minL = line.min(0)
    for j, e in enumerate(line):
        if e == minL:
            posMinLine.append((j, e))
            continue

print(posMinLine)


minLine = lambda line : line.min(1)

print(minLine(a))